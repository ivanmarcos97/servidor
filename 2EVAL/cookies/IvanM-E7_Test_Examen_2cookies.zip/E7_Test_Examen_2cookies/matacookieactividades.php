<?php
//para destruir la cookie y hacer pruebas
setcookie('examen',"",time()-3);
setcookie('test',"",time()-3);
