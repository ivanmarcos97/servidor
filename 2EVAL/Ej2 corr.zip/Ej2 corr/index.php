<?php
require_once("./vista/oposiciones.html");
?>