<?php
//defino el array asociativo
$provincias=array(
	"A coruña"=>array(2000,700),
	"Lugo"=>array(8000,7000), 
	"Ourense"=>array(8500,2000),
    "Pontevedra"=>array(2500,200)
);
	
