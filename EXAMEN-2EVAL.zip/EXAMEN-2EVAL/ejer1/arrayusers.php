
<?php

$usuarios = array(
    'LUIS',
    'MARIA',
);
