<?php

require_once("../vista/elegir.php");
